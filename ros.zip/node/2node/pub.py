#!/usr/bin/env python 3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class publisher(Node):
    def __init__(self):
        super().__init__('pub')
        self.get_logger().info('pub started')
        self.counter_=0
        self.publisher_=self.create_publisher(String,'/message',10)
        self.create_timer(1.0,self.publish_message)
        
    def publish_message(self):
        msg=String()
        msg.data='hello' #+ str(self.counter)
        self.publisher_.publish(msg)
        self.counter_=self.counter_ +1
            




def main(args=None):
    rclpy.init(args=args)
    node=publisher()
    rclpy.spin(node)
    rclpy.shutdown()
    





if __name__=="__main__":
    main()
